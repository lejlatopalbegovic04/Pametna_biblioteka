const express = require("express");
const cors = require("cors");
const fs = require("fs");

// const isAuthenticated = require("./middlewares/isAuthenticated");
const { ENVS } = require("./env");

const app = express();

const corsOptions = { origin: "*" };

app.use(cors(corsOptions));
// app.use(isAuthenticated)
// app.use(express.json());

// Generate routes
const routes = fs
  .readdirSync(`${ENVS.PROJECT_ROOT}/routes`)
  .filter(
    (entery) => !fs.statSync(`${ENVS.PROJECT_ROOT}/routes/${entery}`).isFile()
  )
  .forEach(route => {
    app.use(`/api/${route}`, require(`${ENVS.PROJECT_ROOT}/routes/${route}/index`))
  })

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.listen(Number(ENVS.BACKEND_PORT), () => {
  console.log(`Example app listening on port ${ENVS.BACKEND_PORT}`);
});
