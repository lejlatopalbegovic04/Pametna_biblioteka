//const ENVS = require("./config/envs").ENVS;

const { migrateDb } = require("./scripts/migrateDb");

(async () => {
  await migrateDb();
})();

//console.log(ENVS)
