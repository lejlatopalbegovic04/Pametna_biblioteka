const path = require("path")

require('dotenv').config();

const ENVS = {
    PROJECT_ROOT: path.dirname(process.argv[1])
};

[
    "SECRET",
    "BACKEND_PORT",
    "DATABASE_HOST",
    "DATABASE_USER",
    "DATABASE_PASSWORD",
    "DATABASE_NAME",
    "FILE_STORAGE_PATH"
].forEach(key => ENVS[key]=process.env[key]) 

module.exports = {
    ENVS
}