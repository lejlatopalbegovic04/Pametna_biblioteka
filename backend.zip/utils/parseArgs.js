const ARG_TYPE = [
  (value) => {
    try {
      return JSON.parse(value);
    } catch (err) {
      return undefined;
    }
  },
  (value) => {
    try {
      return eval(`${value}`);
    } catch (err) {
      return undefined;
    }
  },
  (value) => value,
];

const parseType = (value) => {
  for (let elem in ARG_TYPE) {
    let res = ARG_TYPE[elem](value);
    if (res) return res;
  }

  return undefined;
};

const parseArgs = () => {
  const args = {};

  const argsRow = process.argv.slice(3);
  for(let i=0;i<argsRow.length;i++){
    try{
      args[argsRow[i].split(":")[0]] = parseType(argsRow[i].split(":")[1]);
    }
    catch(err) {
      console.log(`[ERROR] Wrong argument: '${argsRow[i].split(":")[0]}'`)
    }
  }

  return args;
};


module.exports = parseArgs;
