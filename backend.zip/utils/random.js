const randomRange = (min, max) => min + Math.random() * (max - min);
const iRandomRange = (min, max) => Math.round(randomRange(min, max));

const CHARSET_UPPERCASE = "QWERTYUIOPASDGJKLZXCBNM";
const CHARSET_LOWERCASE = "qwertyuiopasdgjklzxcbnm";
const CHARSET_NUMBERS = "1234567890";

const randomString = (
  length,
  charset = `${CHARSET_UPPERCASE}${CHARSET_LOWERCASE}${CHARSET_NUMBERS}`
) =>
  Array(length)
    .fill(null)
    .map((_) => charset[iRandomRange(0, charset.length - 1)])
    .join("");

module.exports = {
  randomRange,
  iRandomRange,
  randomString,
};
