const fs = require('fs');
const { promisify } = require('util');
const { exec } = require('child_process');



const createPdfCover = async (pathToFile, createPath) => {
  try {
    const convertCommand = `convert -density 150 "${pathToFile}[0]" -quality 100 "${createPath}"`;
    await promisify(exec)(convertCommand);

    console.log('Conversion complete');
  } catch (error) {
    console.error('Error converting PDF to JPG:', error);
    throw "Failed to create icon!";
  }
};

module.exports = createPdfCover;
