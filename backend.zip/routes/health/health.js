const { randomString } = require("../../utils/random");

const health = (req, res) => {
    res.send({status: 'success'});
}

module.exports = health;
