const createBook = async (reqeust, response) => {
  const data = {
    firstName: request.body.firstName,
    lastName: request.body.lastName,
    email: request.body.email,
    secret: hashString(`${request.body.email}${request.body.password}`, ENVS.SECRET),
    role: request.body.role,
  }
}