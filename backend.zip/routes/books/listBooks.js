const Book = require("../../models/book");
const Author = require("../../models/author");
const File = require("../../models/file");

require("../../models/relationships/book");

const { Sequelize, Op } = require("sequelize");
const User = require("../../models/user");

const {BOOK_STATUS_PUBLISHED} = require("../../constants/book");

const listBooks = async (request, response) => {
  const whereStatement = {
    status: BOOK_STATUS_PUBLISHED
  };

  if(request?.query?.name) {
    whereStatement.name = {
      [Sequelize.Op.like]: `%${request?.query?.name}%`
    }
  }

  if(request?.query?.genre) {
    whereStatement.genre = {
      [Op.and]: request?.query?.genre.split(",").map(stat => ({
        [Op.like]: `%${stat}%`
      }))
    }
  }
  
  if(request?.query?.authorId) {
    whereStatement.authorId = Number(request?.query?.authorId)
  }

  if(request?.query?.publisherId) {
    whereStatement.userId = Number(request?.query?.publisherId)
  }

  
  if(request?.query?.id) {
    whereStatement.id = request?.query?.id;
  }

  const orderByStatement = (request?.query?.order || '')
    .split(',')
    .filter(orderItem => orderItem && orderItem?.length > 0)
    .map(orderItem => orderItem[0] === "-" ? [orderItem.slice(1), "DESC"] : [orderItem, "ASC"]);

  const limit = request?.query?.limit;
  const offset = request?.query?.offset;

  const query = {}
  if(Object.keys(whereStatement).length > 0) query.where = whereStatement;
  if(orderByStatement.length > 0) query.order = orderByStatement;
  if(limit) query.limit = Number(limit);
  if(offset) query.offset = Number(offset);


  const results = await Book.findAndCountAll({
    ...query,
    include: [{model: Author, as: 'author'}, {model: File, as: 'file'}, {model: User, as: 'user'}]
  })


  response.status(200).send({
    count: results.count,
    total: results.rows.map(book => ({
      id: book.id,
      name: book.name,
      description: book.description,
      genre: book.genre,
      author: book.author ? {
        id: book.author.id,
        firstName: book.author.firstName,
        lastName: book.author.lastName,
        description: book.author.description
      } : null,
      iconUrl: book?.file?.iconUrl,
      url: book?.file?.url,
      publisher: {
        id: book.user.id,
        firstName: book.user.firstName,
        lastName: book.user.lastName
      }
    }))
  })
}

module.exports = listBooks;
