const express = require('express');
const multer = require("multer");
const { ENVS } = require('../../env');
const isAuthenticated = require('../../middlewares/isAuthenticated');
const router = express.Router();
const hashString = require("../../libs/auth/hash");
const { randomString } = require('../../utils/random');


const storage = multer.diskStorage({ 
  destination: ENVS.FILE_STORAGE_PATH,
  filename: (request, file, cb) => {
    const filenameExtension = file.originalname.split(".").at(-1);
    cb(null, `${randomString(32)}.${filenameExtension}`)
  },
});

const upload = multer({ storage });

router.post("/create/upload", isAuthenticated, upload.single('file'), require("./uploadBook"));
router.get("/list/my", isAuthenticated, express.json(), require("./listMyBooks"));
router.get("/list", isAuthenticated, express.json(), require("./listBooks"));

//router.post("/create/upload", isAuthenticated, upload.single('file'), require("./uploadBook"));

//router.get('/', require('./health'));

module.exports=router;