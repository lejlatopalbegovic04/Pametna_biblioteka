const Book = require("../../models/book");
const File = require("../../models/file");
const createPdfCover = require("../../utils/createPdfCover");

const uploadBook = async (request, response) => {
  const slicedFileName = request.file.filename.split(".");
  const iconPath = `${request.file.destination}${slicedFileName
    .slice(0, slicedFileName.length - 1)
    .join("")}_icon.jpg`;

  
  try {
    await createPdfCover(request.file.path, iconPath);
  } catch (err) {
    console.log(err);
    response.status(500).send({ message: err?.message || err });
    return;
  }

  try {
    const file = await File.create({
      url: request.file.path,
      iconUrl: iconPath,
    });
    const book = await Book.create({
      userId: request.user.id,
      fileId: file.id,
    });
    
    response.status(200).send({
      id: book.id,
      url: file.url,
      iconUrl: file.iconUrl,
    });
  } catch (err) {
    response.status(500).send({
      message: err?.message || err,
    });
  }
};

module.exports = uploadBook;
