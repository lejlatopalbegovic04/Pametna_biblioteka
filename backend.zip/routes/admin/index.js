const express = require('express');
const isAdmin = require('../../middlewares/isAdmin');
const isAuthenticated = require('../../middlewares/isAuthenticated');
const router = express.Router();

router.post('/users/create', isAuthenticated, isAdmin, express.json(), require('./users/createUser'));
router.get('/users/list', isAuthenticated, isAdmin, express.json(), require('./users/listUsers'));
router.post('/users/update', isAuthenticated, isAdmin, express.json(), require('./users/updateUser'));

//router.post('/admin/file/create', express.json(), require('./login'));
//router.post('/admin/file/list', express.json(), require('./login'));
//router.post('/admin/file/update', express.json(), require('./login'));


module.exports=router;