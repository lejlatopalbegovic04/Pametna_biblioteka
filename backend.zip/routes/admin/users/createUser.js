const User = require("../../../models/user");
const hashString = require("../../../libs/auth/hash");
const { ENVS } = require("../../../env");
const { Sequelize } = require("sequelize");

const createUser = async (request, response) => {
  const userExists = await User.findOne({
    where: {
      email: {
        [Sequelize.Op.like]: request.body.email,
      },
    },
  });

  if (userExists) {
    response.status(400).send({"message": `User with email ${request.body.email} already exists`})
    return;
  }


  const data = {
    firstName: request.body.firstName,
    lastName: request.body.lastName,
    email: request.body.email,
    secret: hashString(`${request.body.email}${request.body.password}`, ENVS.SECRET),
    role: request.body.role,
  }

  try {
    const user = await User.create(data);

    response.status(209).send({
      firstName: user.firstName,
      lastName: user.lastName,
      id: user.id,
      email: user.email,
      role: user.role,
    });
  } catch (err) {
    response.status(400).send({"message": `User with email ${request.body.email} already exists`});
  }
}

module.exports = createUser;
