const User = require("../../../models/user");
const hashString = require("../../../libs/auth/hash");
const { ENVS } = require("../../../env");


const updateUser = async (request, response) => {
  const user = await User.findOne({
    where: {
      id: request.body.id,
    },
  });

  if (!user) {
    response
      .status(400)
      .send({ message: `User with id ${request.body.id} does not exists!` });
    return;
  }

  const data = {
    firstName: request.body.firstName,
    lastName: request.body.lastName,
    email: request.body.email,
    secret: request.body.password
      ? hashString(`${request.body.email}${request.body.password}`, ENVS.SECRET)
      : undefined,
    role: request.body.role,
    active: request.body.active
  };

  for (let key in data) {
    if (data[key] !== undefined) user[key] = data[key];
  }

  try{
    user.save();
    response.status(209).send({
      firstName: user.firstName,
      lastName: user.lastName,
      id: user.id,
      email: user.email,
      role: user.role,
      active: user.active
    });
  }catch(err){
    response
      .status(500)
      .send({
        message: err?.message || err,
      });
  }
};

module.exports = updateUser;
