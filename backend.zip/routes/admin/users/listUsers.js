const { request } = require("express");
const User = require("../../../models/user");
const { Sequelize, where } = require("sequelize");

const listUsers = async (request, response) => {
  const whereStatement = {};


  if(request?.query?.firstName) {
    whereStatement.firstName = {
      [Sequelize.Op.like]: `%${request?.query?.firstName}%`
    }
  }

  if(request?.query?.lastName) {
    whereStatement.lastName = {
      [Sequelize.Op.like]: `%${request?.query?.lastName}%`
    }
  }

  if(request?.query?.email) {
    whereStatement.email = {
      [Sequelize.Op.like]: `%${request?.query?.email}%`
    }
  }

  if(request?.query?.role) {
    whereStatement.role = {
      [Sequelize.Op.like]: request?.query?.role
    }
  }

  if(request?.query?.id) {
    whereStatement.id = request?.query?.id;
  }

  const orderByStatement = (request?.query?.order || '')
    .split(',')
    .filter(orderItem => orderItem && orderItem?.length > 0)
    .map(orderItem => orderItem[0] === "-" ? [orderItem.slice(1), "DESC"] : [orderItem, "ASC"]);

  const limit = request?.query?.limit;
  const offset = request?.query?.offset;

  const query = {}
  if(Object.keys(whereStatement).length > 0) query.where = whereStatement;
  if(orderByStatement.length > 0) query.order = orderByStatement;
  if(limit) query.limit = Number(limit);
  if(offset) query.offset = Number(offset);


  console.log(query)


  const results = await User.findAndCountAll(query)


  response.status(200).send({
    count: results.count,
    total: results.rows.map(user => ({
      firstName: user.firstName,
      lastName: user.lastName,
      id: user.id,
      email: user.email,
      role: user.role,
      active: user.active
    }))
  })
}

module.exports = listUsers;
