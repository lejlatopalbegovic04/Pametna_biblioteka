const logout = async (request, response) => {
  await request.session.destroy()

  response.status(200).send()
};

module.exports = logout;
