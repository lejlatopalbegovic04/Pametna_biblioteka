const { Sequelize } = require("sequelize");
const { ENVS } = require("../../env");
const hashString = require("../../libs/auth/hash");
const Session = require("../../models/session");
const User = require("../../models/user");
const { randomString } = require("../../utils/random");

const login = async (request, response) => {
  try {
    const user = await User.findOne({
      where: {
        secret: {
          [Sequelize.Op.like]: hashString(
            `${request.body.email}${request.body.password}`,
            ENVS.SECRET
          ),
        },
      },
    });

    if (!user.active) {
      response.status(404).send({ message: "User does not exists" });
      return;
    }

    await Session.destroy({
      where: {
        userId: user.id,
      },
    });

    const session = await Session.create({
      userId: user.id,
      authToken: randomString(128),
    });

    response.setHeader("auth-token", session.authToken);
    response.send({
      firstName: user.firstName,
      lastName: user.lastName,
      id: user.id,
      email: user.email,
      role: user.role,
    });
  } catch (err) {
    response.status(500).send({ message: err?.message || err });
  }
};

module.exports = login;
