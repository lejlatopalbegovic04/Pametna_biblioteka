const express = require('express');
const isAuthenticated = require('../../middlewares/isAuthenticated');
const router = express.Router();

router.get('/current', isAuthenticated, express.json(), require('./current'));
router.post('/login', express.json(), require('./login'));
router.delete('/logout', isAuthenticated, express.json(), require('./logout'));

module.exports=router;