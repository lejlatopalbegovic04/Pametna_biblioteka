const currentUser = async (request, response) => {
  response.send({
    firstName: request.user.firstName,
    lastName: request.user.lastName,
    id: request.user.id,
    email: request.user.email,
    role: request.user.role
  });
};

module.exports=currentUser
