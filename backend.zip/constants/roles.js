const ROLE_TYPE_ADMIN = "admin";

module.exports = { ROLE_TYPE_ADMIN };
