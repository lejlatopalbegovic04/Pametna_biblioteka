const COMMANDS = require("./commands/index");

const ARGS = require("./utils/parseArgs")();

if (!ARGS?.command) {
  console.log(`[ERROR] 'command' argument is missing`);
  process.exit(500);
}

(async () => {
  await COMMANDS[ARGS?.command].function(
    ...COMMANDS[ARGS?.command]?.arguments?.map((arg) => ARGS[arg])
  );
})();
