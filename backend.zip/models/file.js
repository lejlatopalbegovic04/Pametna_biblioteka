const { DataTypes, Sequelize } = require("sequelize");
const { sequelize } = require("../config/sequelize");

const File = sequelize.define("File", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  url: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  iconUrl: {
    type: DataTypes.STRING,
    allowNull: true,
  }
});


module.exports = File;
