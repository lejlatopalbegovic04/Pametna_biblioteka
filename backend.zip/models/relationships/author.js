
const Book = require("../book");
const Author = require("../author");

Author.hasMany(Book, {
  foreignKey: {
    name: "authorId",
    allowNull: true, // Allow null values for the foreign key
  },
  as: "books",
});
