const Author = require("../author");
const User = require("../user");
const File = require("../file");
const Book = require("../book");

Book.belongsTo(Author, {
  foreignKey: {
    name: "authorId",
    allowNull: true,
  },
  as: "author",
});

Book.belongsTo(User, {
  foreignKey: {
    name: "userId",
    allowNull: true,
  },
  as: "user"
});

Book.belongsTo(File, {
  foreignKey: {
    name: "fileId",
    allowNull: true
  },
  as: 'file'
})
