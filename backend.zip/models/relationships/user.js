const Book = require("../book");
const User = require("../user");

User.hasMany(Book, {
  foreignKey: {
    name: "userId",
    allowNull: true, // Allow null values for the foreign key
  },
  as: "postedBooks",
});
