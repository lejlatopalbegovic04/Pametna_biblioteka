const User = require("../user");
const Session = require("../session");

//Session.associate = (model) => {
Session.belongsTo(User, {
  foreignKey: {
    name: "userId",
    allowNull: true,
  },
  as: "user",
});


//User.hasOne(Session);
