const fs = require("fs");

const { sequelize } = require("../config/sequelize");
const { ENVS } = require("../env");

const MODELS_PATH = `${ENVS.PROJECT_ROOT}/models`;
const RELATIONSHIPS_PATH = `${MODELS_PATH}/relationships`;

const migrateDb = async () => {
  // Find Model definitions
  const definitions = fs
    .readdirSync(MODELS_PATH)
    .filter((file) => {
      try {
        return fs.statSync(`${MODELS_PATH}/${file}`).isFile();
      } catch (err) {
        return false;
      }
    })
    ?.map((localPath) => ({
      path: `${MODELS_PATH}/${localPath}`,
      name: `${(localPath[0].toUpperCase() + localPath.slice(1)).split(".")[0]}Model`,
    }));

  // Find Relationship definitions
  definitions.push(
    ...fs
      .readdirSync(RELATIONSHIPS_PATH)
      .filter((file) => {
        try {
          return fs.statSync(`${RELATIONSHIPS_PATH}/${file}`).isFile();
        } catch (err) {
          return false;
        }
      })
      ?.map((localPath) => ({
        path: `${RELATIONSHIPS_PATH}/${localPath}`,
        name: `${(localPath[0].toUpperCase() + localPath.slice(1)).split(".")[0]}Relationships`,
      }))
  );

  // const SCHEMA = {};
  for (let i = 0; i < definitions.length; i++) {
    require(definitions[i].path);
    // SCHEMA[definitions[i].name] = definitions[i].path;
  }

  await sequelize.sync({ force: true });
};

module.exports = {
  function: migrateDb,
  arguments: []
}
