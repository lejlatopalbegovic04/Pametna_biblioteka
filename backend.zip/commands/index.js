const createUser = require("./createUser");
const migrateDb = require("./migrateDb");

module.exports = {
    migrate: migrateDb,
    createUser: createUser
}