const { Sequelize } = require("sequelize");
const { sequelize } = require("../config/sequelize");
const { ENVS } = require("../env");
const hashString = require("../libs/auth/hash");
const User = require("../models/user");

const createUser = async (
  firstName,
  lastName,
  email,
  password,
  role = null
) => {
  const userExists = await User.findOne({
    where: {
      email: {
        [Sequelize.Op.like]: email,
      },
    },
  });

  if (userExists) {
    console.log(`User with email ${email} already exists!`);
    return;
  }

  try {
    const user = await User.create({
      firstName: firstName,
      lastName: lastName,
      email: email,
      secret: hashString(`${email}${password}`, ENVS.SECRET),
      role: role,
    });
  } catch (err) {
    console.log(`[ERROR] ${err}`);
  }
};

module.exports = {
  function: createUser,
  arguments: ["firstName", "lastName", "email", "password", "role"],
};
