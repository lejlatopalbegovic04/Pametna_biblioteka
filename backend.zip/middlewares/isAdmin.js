const { ROLE_TYPE_ADMIN } = require("../constants/roles");

const isAdmin = async (request, response, next) => {
  if(!request.user.role === ROLE_TYPE_ADMIN){
    response.status(403).send({
      status: "error",
      message: "Not authorised",
    });
    return;
  }

  next();
};

module.exports = isAdmin;
