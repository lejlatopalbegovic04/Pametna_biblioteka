const Session = require("../models/session");
require("../models/relationships/session");

const User = require("../models/user");

const isAuthenticated = async (request, response, next) => {
  try {
    const token = request.headers["auth-token"];
    request.session = (
      await Session.findOne({
        include: { model: User, as: "user" },
        where: {
          authToken: token,
        },
      })
    );

    request.user = request.session.user;

    if(!request.user.active) {
      response.status(403).send({
        status: "error",
        message: "Not authenticated",
      });
      return;
    }

    next();
  } catch (err) {
    console.log(err);
    response.status(403).send({
      status: "error",
      message: "Not authenticated",
    });
  }
};

module.exports = isAuthenticated;
