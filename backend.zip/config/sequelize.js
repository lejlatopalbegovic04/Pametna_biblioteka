const { ENVS } = require("../env");
const { Sequelize } = require('sequelize');

const DATABASE_URL = `mysql://${ENVS.DATABASE_USER}:${ENVS.DATABASE_PASSWORD}@${ENVS.DATABASE_HOST}/${ENVS.DATABASE_NAME}`
const sequelize = new Sequelize(DATABASE_URL)

module.exports = {
    sequelize
}