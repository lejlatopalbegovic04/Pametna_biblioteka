const Singleton = require("./utils/singleton").Singleton;

class ProcessCache extends Singleton {
    ENVS = {}
}

module.exports = {
    ProcessCache
}