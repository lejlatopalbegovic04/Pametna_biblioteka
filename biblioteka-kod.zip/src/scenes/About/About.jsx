import "./About.css";

export default function About() {
  return (
    <section className="about-us">
      <div className="about">
        <div className="about-text">
          <h2>Meet The Team</h2>
          <h5>Online Studentska Biblioteka Team </h5>
          <p>Lejla Topalbegovic</p>
          <p>Azra Kazija</p>
          <p>Sulejman Vojvodic</p>
          <p> Munir Karic</p>
          <p> Kerim Nezo</p>
          <p> Mahir Prcanovic</p>
          <div className="data">
            <a href="./contact-us" className="contact-btn">
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
