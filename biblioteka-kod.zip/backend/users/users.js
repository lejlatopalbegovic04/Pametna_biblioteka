const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const database = require('../database/database');


const createPasswordHash = async(password) => {
   
    const saltRounds = 10;
    
 
    const hashedPassword = await new Promise((resolve, reject) => {
        bcrypt.hash(password, saltRounds, function(err, hash) {
           
            if (err) reject(err);

            
            resolve(hash);
        });
    });

    console.log(`User password Hash: ${hashedPassword}`);
    return hashedPassword;
}


const verifyHash = async (userHash, pass) => {
    const match = await bcrypt.compare(pass, userHash);

    return match;
}

const createUser = async (email, password) => {
    try {
        console.log("Pokušaj dodavanja novog korisnika u bazu podataka...");

        const userHash = await createPasswordHash(password);
       
        const payload = {
            email: email,
            hash: userHash,
            role: 'user',
            refresh_token: ''
        };

        const response = await database.createEntry('users', payload);

     
        if (response) {
            console.log("Uspješno kreiran novi korisnički unos u bazi!");
            return true;
        } else {
            console.log("Stvaranje novog korisničkog unosa nije uspjelo.");
            return false;
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}



const signInUser = async (email, pass) => {
    try {
   
        const query = {
            email: email
        }

        const user = await database.readEntry('users', query);
    
        if (!user) {
            console.log("Korisnik sa tom e-mail adresom ne postoji...");
            return false;
        } else {
           
            const userHash = await verifyHash(user.hash, pass);
   
            if (!userHash) {
                console.log("Unijeta lozinka nije ispravna.");
                return false;
            } else {
               
                console.log("Email i lozinka ispravni! pokusaj projavljivsnja korisnika...");
              
                const payload = {
                    id: user._id,
                    email: user.email,
                    role: user.role,
                };
              
                const accessToken = jwt.sign(
                    payload,
                    'mysecretaccesskey',
                    {
                        expiresIn: '15m'
                    }
                )
                const refreshToken = jwt.sign(
                    payload,
                    'mysecretrefreshkey',
                    {
                        expiresIn: '30d'
                    }
                )

                const tokenResponse = await database.updateEntry('users', query, 'set', refreshToken, 'refresh_token');
                if (tokenResponse) {
                    console.log('Successfully added refresh token to the database!');
                    console.log('Successfully signed in User!');
                    return { message: "Login Successful", role: user.role, accessToken: accessToken, refreshToken: refreshToken };
                } else {
                    console.log('Failed to add refresh token to database.');
                    return false;
                }
            }
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}

const signOutUser = async (refreshToken) => {
    console.log("Attempting to sign out user...");
    try {
        const decoded = await new Promise ((resolve, reject) => {
            jwt.verify(
                refreshToken,
                'mysecretrefreshkey',
                (err, decoded) => {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(decoded);
                    }
                }
            )
        });

        const userExists = await database.readEntry('users', { email: decoded.email });

        if(!userExists) {
            return;
        }

        const tokenResponse = await database.updateEntry('users',
            { email: decoded.email },
            'set', '', 'refresh_token');

        if(tokenResponse) {
            return;
        }
    } catch (err) {
        console.log(err);
        return;
    }
}

const handleRefreshToken = async (refreshToken) => {
    console.log("Attempting to refresh user's access token...");
    
    let accessToken = '';
    let role = '';


    jwt.verify(
        refreshToken,
        'mysecretrefreshkey',
        (err, decoded) => {
        
            if (err) {
                return { status: 403 }
            }
          
            const payload = {
                id: decoded._id,
                email: decoded.email,
                role: decoded.role,
            };
       
            accessToken = jwt.sign(
                payload,
                'mysecretaccesskey',
                { expiresIn: '15m' }
            )
            // Success!
            console.log("User access token refreshed!");
            role = decoded.role;
        }
    )
    return { message: "Refreshed Access Token!", role: role, accessToken: accessToken };
}

module.exports = {
    createUser,
    signInUser,
    handleRefreshToken,
    signOutUser
}