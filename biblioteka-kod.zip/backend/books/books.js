const database = require('../database/database');

// Creates a book, you get the idea from the users/ database one
const createBook = async (data) => {
    const { 
        title, 
        author, 
        genre,
        category,
        desc, 
        price 
    } = data;

    try {
        console.log("Pokusaj dodavanja nove knjige u bazu podataka...");

        const payload = {
            title: title,
            author: author,
            genre: genre,
            desc: desc,
            stripe_id: '',
            category: category,
            avail_inventory: 5
        }

        const response = await database.createEntry('books', payload);
        if (response) {
            console.log("Uspješno kreiran novi unos knjige u bazi podataka!");
            return response;
        } else {
            console.log("Stvaranje novog unosa knjige nije uspjelo.");
            return false;
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}


const updateBook = async(book, data) => {
    console.log("Azuriranje knjige novim podacima...");
    console.log(book, data);
    const query = {
        _id: book
    }
    try {
        const updateResponse = await database.updateEntry('books', query, 'set', data, 'stripe_id');
        if (updateResponse) {
            return true;
        } else {
            return false;
        }
    } catch (err) {
        console.log(err);
    }
}


const updateBookInventory = async (book, qty) => {
    console.log("Ažuriranje liste knjiga...");
    console.log(book);
    const query = {
        title: book
    }

    try {
        const updateResponse = await database.updateEntry('books', query, 'inc', qty * -1, 'avail_inventory');
        return updateResponse;
    } catch (err) {
        console.log(err);
        return false;
    }
}

// Umjesto običnog readEntry-ja, ovaj koristi readEntryArray
// Razlika je prije nego vraćanje pojedinačnog objekta
// dobivamo niz objekata => [{},{},{}]
const getBooks = async (query={}, sort={ title: 1 }) => {
    const books = database.readEntryArray('books', query, sort);
    if (books) {
        console.log("Uspješno preuzete knjige!");
        return books;
    } else {
        console.log("Dohvaćanje knjiga nije uspjelo");
        return false;
    }
}

module.exports = {
    createBook,
    updateBook,
    updateBookInventory,
    getBooks
}