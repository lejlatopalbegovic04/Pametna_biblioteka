const { MongoClient } = require('mongodb');
const uri = 'mongodb+srv://lejla12:lejla12@cluster0.ttgqs94.mongodb.net/';
const client = new MongoClient(uri);


const connectToDatabase = async () => {
    console.log("Creating connection to MongoDB Database...");
    try {
    
        const database = client.db('biblioteka');

 
        return database;
    } catch (err) {
        console.log(err);
    }
}



const createEntry = async (table, payload) => {
    console.log("Pokušaj kreiranja novog unosa u bazi podataka...");
    try {
       
        const conn = await connectToDatabase();
        
        const coll = await conn.collection(table);


        const response = await coll.insertOne(payload);
     
        if (response) {
            console.log("Uspješno kreiran novi unos baze podataka!");
            return response;
        } else {
            console.log("Stvaranje novog unosa baze podataka nije uspjelo.");
            return false;
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}


const readEntry = async (table, query) => {
    console.log("Pokušaj pronalaska unosa u bazi podataka koji odgovara navedenom upitu...");
    try {
        const conn = await connectToDatabase();
        const coll = await conn.collection(table);

     
        const result = await coll.findOne(query);
        if (result) {
            console.log("Uspješno pronađen unos koji odgovara navedenom upitu!");
            return result;
        } else {
            console.log("Nije uspjelo pronaći unos koji odgovara navedenom upitu.");
            return false;
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}


const readEntryArray = async (table, query, sort) => {
    try {
        const conn = await connectToDatabase();
        const coll = await conn.collection(table);
        const queryResult = await coll.find(query).sort(sort).toArray();
        if (queryResult){
            return queryResult;
        } else {
            return false;
        }
    } catch (err) {
        console.log(err);
    }
}


const updateEntry = async (table, query, action="set", payload, location="") => {
    console.log("Pokušaj ažuriranja unosa u bazi podataka...");
    try {
        const conn = await connectToDatabase();
        const coll = await conn.collection(table);


        const item = await coll.findOne(query);
        if (!item){
            console.log("Nema pronađenih stavki koje odgovaraju navedenom upitu");
            return false;
        } else {
            try {
             
                switch (action) {
                   
                    case "set":
                        const setResponse = await coll.updateOne(query, { $set: { [location]: payload } });
                        if (setResponse) {
                            console.log("Ciljani unos je uspješno ažuriran novim podacima");
                            return true;
                        }
                        break;
               
                    case "inc":
                        const incQuery = {};
                        incQuery[location] = payload;
                        const incResponse = await coll.updateOne(
                            query, 
                            { $inc: incQuery }
                        );
                        if (incResponse) {
                            console.log("Uspješno ažurirana količina ciljanog unosa");
                            return true;
                        }
                        break;
                }
                return true;
            } catch (err) {
                console.log(err);
                return false;
            }  
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}

const deleteEntry = async (table, query) => {
    console.log("Pokušaj brisanja unosa iz baze podataka...");
    try {
        const conn = await connectToDatabase();
        const coll = await conn.collection(table);

        const item = await coll.findOne(query);
        if (!item) {
            console.log("Nije uspjelo pronaći unos koji odgovara navedenom upitu.");
            return false;
        } else {
            console.log("Uspješno pronađen unos koji odgovara navedenom upitu!");
            const response = await coll.deleteOne(query);
            if (response) {
                console.log("Unos je uspješno izbrisan iz baze podataka!");
                return true;
            } else {
                console.log("Brisanje unosa iz baze podataka nije uspjelo.");
                return false;
            }
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}

const deleteAll = async (table, query={}) => {
    console.log("Pokušaj uklanjanja svih unosa iz navedene zbirke...");
    try {
        const conn = await connectToDatabase();
        const coll = await conn.collection(table);

        const deleteResponse = await coll.deleteMany(query);
        if (deleteResponse) {
            return deleteResponse
        } else {
            return false;
        }
    } catch (err) {
        console.log(err);
        return false;
    }
}

module.exports = {
    createEntry,
    readEntry,
    readEntryArray,
    updateEntry,
    deleteEntry,
    deleteAll
}